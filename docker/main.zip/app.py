from fastapi import FastAPI
import uvicorn

app = FastAPI()

@app.get("/")
def status():
    return {"status": "saveimage server is running"}